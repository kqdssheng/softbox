Author: BlueLife, Velociraptor
www.sordum.org

########################--Backup Start Menu Layout  v1.6 --########################

Thursday, September 22, 2022
-----------------------
[FIXED] � Error: Reg file could not be created
[Added] � Some code Improvements

########################--Backup Start Menu Layout  v1.5 --########################

Thursday, 7 October 2021
-----------------------
[Added] � Windows 11 Support
[Added] � Confirmation message to Reset Start Menu option
[Added] � Some code Improvements
[FIXED] � Some Minor BUGS

########################--Backup Start Menu Layout  v1.4 --########################

Thursday, 15 October 2020
-----------------------
[FIXED] � The font in the list is too small
[FIXED] � If you run it with administrator privileges in a limited user, Admin account Start Menu is processed
[Added] � Language Support
[Added] � Sorting list by pressing the headline
[Added] � Disable Uninstallation,Right Click and Drag & drop of Pinned Tiles
[Added] � Open Start Menu Program Folder (Under the File menu)

########################-- Backup Start Menu Layout  v1.3 --########################

Monday, July 15, 2019
-----------------------
[Added] � The ability to name a backup for /C command line switch

########################-- Backup Start Menu Layout  v1.2 --########################

Thursday, May�s 30, 2019
-----------------------
[Fixed] - Some minor BUGs

########################-- Backup Start Menu Layout  v1.1 --########################

Saturday, September 15, 2018
-----------------------
[Fixed] - Some minor BUGs

########################-- Backup Start Menu Layout  v1.0 --########################

Thursday, September 13, 2018
-----------------------
A simple tool to backup and restore Start Menu layout


