Author: BlueLife , Velociraptor
www.sordum.org

###################--DNS Lock v1.4--###################
(Saturday, 16. February 2019)

-[Added] Parameter support
-[Added] x64 version

###################--DNS Lock v1.3--###################
(Monday, 14. November 2016)

-[Fixed] Cpu usage of the Dns lock reduced again
-[Fixed] A minor BUG of the Dns change mechanism
-[Added] Defauld Dns Feature
-[Added] A small Button Added (Home page,contact,donate)

###################--DNS Lock v1.2--###################
(Saturday, 05. November 2016)

-[Fixed] Cpu usage is between 0,003 - 0,005 (reduced)
-[Fixed] Many false positive warning
-[Fixed] A minor code BUG


###################--DNS Lock v1.1--###################
(Wednesday, 02. November 2016)

-[Added] IPv6 Support
-[Added] Status indicator
-[Fixed] Spelling errors

###################--DNS Lock v1.0--###################
(Saturday, 29. October 2016)

A simple Portable freeware to Protect your DNS settings , DNS Lock can keep ipv4/6 Preferred DNS servers constant