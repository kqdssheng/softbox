Author: BlueLife , Velociraptor
www.sordum.org

############--Hibernate Enable or Disable v1.3--############
(Thursday, 4. November 2021)

Changelog:

1. [ Added ] - Language support
2. [ Added ] - x64 bit version
3. [ Added ] - Some code Improvements
4. [ Fixed ] - GUI is too small

---------------------------------------------------------------

############--Hibernate Enable or Disable v1.2 --############
(Tuesday, 27. December 2016)

Changelog:

1. [ Fixed ] - A small BUG

---------------------------------------------------------------

############--Hibernate Enable or Disable v1.1 --############
(Tuesday, 27. December 2016)

Changelog:

1. [ Added ] - Hiberfil.sys file size indicator
2. [ Added ] - Minimum,Medium,Maximum,Reduced Size setting feature
3. [ Fixed ] - Logo design

---------------------------------------------------------------

############--Hibernate Enable or Disable v1.0--############
(Saturday, 24. December 2016)

A very simple portable Utility to Disable or Enable Hibernation.




