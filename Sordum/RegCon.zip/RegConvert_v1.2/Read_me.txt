Author: BlueLife , Velociraptor
www.sordum.org

01010101010101010101--Reg Converter v1.2--01010101010101010101

(Monday, 22. January 2018)

1. [ Fixed ] - Convert Clipboard button bug
2. [ Fixed ] - Minor BUGS and some code weakness
3. [ Added ] - Small settings for REG_DWORD registry values
4. [ Added ] - non zero return code in Command line mode 

---------------------------------------------------------------

01010101010101010101--Reg Converter v1.1--01010101010101010101

(Friday, 18. August 2017)

Changelog:


1. [ Fixed ] - Reg_Dword is not fully supported
2. [ Fixed ] - Comments at the end of the Registry Key or values are not supported
3. [ Fixed ] - Minor BUGS and some code weakness
4. [ Added ] - Language Support
5. [ Added ] - Jump to Registry key feature

---------------------------------------------------------------

01010101010101010101--Reg Converter v1.0--01010101010101010101

(April 3, 2014)

First Release - Reg Converter is a portable freeware utility to convert .reg data to .bat, .vbs, or .au3
