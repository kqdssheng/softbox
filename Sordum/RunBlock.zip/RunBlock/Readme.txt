Author: BlueLife , Velociraptor
www.sordum.org

[%%%%%%%%%%%%%%%%%]--Simple Run Blocker v1.5--[%%%%%%%%%%%%%%%%%]
Saturday,2 march 2019
------------
Changelog:

1. [ Added ] - Some code improvements
2. [ Fixed ] - Blocking an Application affects all users, including admin
3. [ Fixed ] - A minor export - import BUG


[%%%%%%%%%%%%%%%%%]--Simple Run Blocker v1.4--[%%%%%%%%%%%%%%%%%]
Wednesday , 11/1/2017
------------
Changelog:

1. [ Added ] - Export / Import Feature
2. [ Added ] - Windows store App block Function
3. [ Fixed ] - Hide or Lock drives function minor BUG
4. [ Fixed ] - Main GUI function Buttons



[%%%%%%%%%%%%%%%%%]--Simple Run Blocker v1.3--[%%%%%%%%%%%%%%%%%]
(06.04.2015)

1. [ Fixed ] - Hide Drives Function doesn't run properly on Windows 8.1 
2. [ Fixed ] - Block all except the List below undo problem (*)
3. [ Fixed ] - Some minor Bugs fixed and Button effect changed

(*): Running "Simple Run blocker" without extracting it and selecting "Block all except the List below" 
feature causes undo problem , This is a typical wrong usage of Simple Run blocker , but users keep to doing it 
to awoid that , we have copied "Simple Run Blocker" into the Program files and created  a desktop shortcut ( Only 
if you select "Block all except the List below" feature) , you can control this feature with editing  RunBlock.ini file :
CopyToProgramFiles=1 (Default usage like above explanation)
CopyToProgramFiles=0 (Disable the Shortcut creation feature)
If you choose second or third features , Simple Run Blocker folder and the Shortcut will automatically 
deleted , you can control this with changing the following values
RemoveFromProgramFiles=1 (Default usage like above explanation)
RemoveFromProgramFiles=0 (Disable auto removing feature)


[%%%%%%%%%%%%%%%%%]--Simple Run Blocker v1.2--[%%%%%%%%%%%%%%%%%]  

(25.09.2014)
------------
Changelog:
1. [ Added ] - Translate GUI
2. [ Added ] - Some minor code improvements


[%%%%%%%%%%%%%%%%%]--Simple Run Blocker v1.1--[%%%%%%%%%%%%%%%%%]

(24.05.2014)
------------
Changelog:
1. [ Added ] � Hide Or Lock Drives
2. [ Added ] - Language support
3. [ Added ] � Show Hidden Files
4. [ Fixed ] � Code improvements and minor bugs