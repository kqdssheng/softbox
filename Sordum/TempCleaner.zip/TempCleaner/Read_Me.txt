Author: BlueLife , Velociraptor
www.sordum.org

[010101010101010101]--Temp Cleaner v1.3--[010101010101010101]

(Sunday, 26 July 2020)
------------
Changelog:
01. FIXED - Temp Cleaner Doesn't work on some Windows systems and give Line 10 Error
02. FIXED - Temp folder cleanup error under Standart user Account 
03. FIXED - If the taskbar location is different,no notification message appears
04. ADDED - x64 version

[010101010101010101]--Temp Cleaner v1.2--[010101010101010101]

(Wednesday , Nov 20, 2013)
------------
Changelog:
FIXED - Some minor BUG Fixes

[010101010101010101]--Temp Cleaner v1.0 and v1.1--[010101010101010101]

(September 18, 2013)
------------
First release A simpel POrtable Application to delete TEMP files.