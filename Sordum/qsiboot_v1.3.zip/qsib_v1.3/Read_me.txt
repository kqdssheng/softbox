Author: BlueLife , Velociraptor
www.sordum.org

@@@@@@@@@@@@@@@@@@@@--Qemu Simple Boot v1.3 (19.10.2017)--@@@@@@@@@@@@@@@@@@@@

What is New
-----------
1. Qemu updated to version 0.15.1.0

@@@@@@@@@@@@@@@@@@@@--Qemu Simple Boot v1.3 (13.10.2014)--@@@@@@@@@@@@@@@@@@@@

What is New
-----------
1. Translate GUI added
2. Some code improvements
3. Free Ram checker function added ( it can be closed from Qsib.ini file)
4. Minimum ram requirement dropped to 32 MB


@@@@@@@@@@@@@@@@@@@@--Qemu Simple Boot v1.2 (04.09.2013)--@@@@@@@@@@@@@@@@@@@@

What is New
-----------
1. Drag and drop error � Fixed
2. Minor interface changes
3. improvement of codes

@@@@@@@@@@@@@@@@@@@@--Qemu Simple Boot v1.1 (05.10.2012)--@@@@@@@@@@@@@@@@@@@@

What is New
-----------
1. X64 compatibility error � Fixed
2. French Language added
3. German translate error � Fixed
4. Boot hangs � Fixed
5. Too long waiting time � Fixed
6. �Reset� and �Open the configuration� buttons added
7. English readme file added (in info folder)


@@@@@@@@@@@@@@@@@@@@--Qemu Simple Boot v1.0 (03.08.2012)--@@@@@@@@@@@@@@@@@@@@

Qemu Simple Boot is a handy and reliable utility that allows you to test bootable 
image before you burn them to a disc. It uses QEMU, which is a known virtual 
machine emulator that can run a virtual OS on the current host without affecting it.
Qemu Simple Boot was mainly designed as a GUI for QEMU, with the purpose of 
helping users who are not accustomed with the console approach that the latter adopts. 
It can work with removable media, CD discs, ISO and IMA images.
The program depends on QEMU, but does not require you to install it separately; 
the download archive contains everything you need in order to properly use it
